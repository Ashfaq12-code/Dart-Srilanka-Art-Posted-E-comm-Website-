/*
  # E-commerce Schema for Dart Board Store

  ## Overview
  Complete e-commerce database schema for dart board and accessories store with shopping cart, orders, and booking approval system.

  ## Tables Created

  1. **products**
     - `id` (uuid, primary key) - Unique product identifier
     - `name` (text) - Product name
     - `description` (text) - Product description
     - `price` (decimal) - Product price
     - `image_url` (text) - Product image URL
     - `category` (text) - Product category (dart-boards, steel-tip, soft-tip, accessories)
     - `stock` (integer) - Available stock quantity
     - `rating` (decimal) - Product rating (0-5)
     - `is_featured` (boolean) - Whether product is featured on homepage
     - `created_at` (timestamptz) - Creation timestamp

  2. **cart_items**
     - `id` (uuid, primary key) - Unique cart item identifier
     - `user_id` (uuid) - User identifier (anonymous or authenticated)
     - `product_id` (uuid, foreign key) - Reference to product
     - `quantity` (integer) - Quantity in cart
     - `created_at` (timestamptz) - Creation timestamp

  3. **orders**
     - `id` (uuid, primary key) - Unique order identifier
     - `customer_name` (text) - Customer name
     - `customer_phone` (text) - Customer phone number
     - `customer_address` (text) - Delivery address
     - `total_amount` (decimal) - Total order amount
     - `status` (text) - Order status (pending, approved, shipped, delivered, cancelled)
     - `notes` (text) - Additional notes
     - `created_at` (timestamptz) - Order creation timestamp
     - `updated_at` (timestamptz) - Last update timestamp

  4. **order_items**
     - `id` (uuid, primary key) - Unique order item identifier
     - `order_id` (uuid, foreign key) - Reference to order
     - `product_id` (uuid, foreign key) - Reference to product
     - `product_name` (text) - Product name snapshot
     - `quantity` (integer) - Quantity ordered
     - `price` (decimal) - Price at time of order
     - `created_at` (timestamptz) - Creation timestamp

  ## Security
  - Row Level Security (RLS) enabled on all tables
  - Public read access for products
  - Cart items: anyone can manage their own cart (by session)
  - Orders: anyone can create, admins can view/update all
  - Order items: readable by anyone, writable only during order creation
*/

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price decimal(10,2) NOT NULL,
  image_url text NOT NULL,
  category text NOT NULL,
  stock integer DEFAULT 0,
  rating decimal(2,1) DEFAULT 5.0,
  is_featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Cart items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity integer DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  customer_address text NOT NULL,
  total_amount decimal(10,2) NOT NULL,
  status text DEFAULT 'pending',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  product_name text NOT NULL,
  quantity integer NOT NULL,
  price decimal(10,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

-- Products policies (public read)
CREATE POLICY "Anyone can view products"
  ON products FOR SELECT
  TO anon, authenticated
  USING (true);

-- Cart items policies (session-based)
CREATE POLICY "Anyone can view their cart"
  ON cart_items FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can add to cart"
  ON cart_items FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update their cart"
  ON cart_items FOR UPDATE
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can delete from cart"
  ON cart_items FOR DELETE
  TO anon, authenticated
  USING (true);

-- Orders policies
CREATE POLICY "Anyone can create orders"
  ON orders FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view orders"
  ON orders FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can update orders"
  ON orders FOR UPDATE
  TO anon, authenticated
  USING (true);

-- Order items policies
CREATE POLICY "Anyone can view order items"
  ON order_items FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can create order items"
  ON order_items FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Insert sample products
INSERT INTO products (name, description, price, image_url, category, stock, rating, is_featured) VALUES
  ('Professional Dartboard', 'Tournament-grade sisal fiber dartboard with razor-thin spider wire for maximum scoring area', 8500.00, 'https://images.pexels.com/photos/3178786/pexels-photo-3178786.jpeg?auto=compress&cs=tinysrgb&w=800', 'dart-boards', 15, 4.8, true),
  ('Steel Tip Dart Set', 'Professional 24g steel tip darts with tungsten barrels and aluminum shafts', 4500.00, 'https://images.pexels.com/photos/6256619/pexels-photo-6256619.jpeg?auto=compress&cs=tinysrgb&w=800', 'steel-tip', 30, 4.9, true),
  ('Electronic Dartboard', 'LED display electronic dartboard with 27 games and multiplayer options', 12500.00, 'https://images.pexels.com/photos/3621958/pexels-photo-3621958.jpeg?auto=compress&cs=tinysrgb&w=800', 'dart-boards', 8, 4.7, true),
  ('Soft Tip Darts Premium', '18g soft tip darts perfect for electronic boards, includes extra tips', 3200.00, 'https://images.pexels.com/photos/3683041/pexels-photo-3683041.jpeg?auto=compress&cs=tinysrgb&w=800', 'soft-tip', 25, 4.6, true),
  ('Dartboard Cabinet Set', 'Solid wood cabinet with dartboard, includes storage for darts and scoreboard', 15000.00, 'https://images.pexels.com/photos/4219654/pexels-photo-4219654.jpeg?auto=compress&cs=tinysrgb&w=800', 'accessories', 5, 4.9, true),
  ('Dart Flights Pack', 'Set of 10 professional dart flights in various designs and colors', 850.00, 'https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg?auto=compress&cs=tinysrgb&w=800', 'accessories', 50, 4.5, true),
  ('Tournament Dartboard Pro', 'Official tournament size dartboard with staple-free bullseye', 9500.00, 'https://images.pexels.com/photos/3178786/pexels-photo-3178786.jpeg?auto=compress&cs=tinysrgb&w=800', 'dart-boards', 12, 5.0, false),
  ('Tungsten Steel Darts', 'Premium 90% tungsten steel tip darts with precision grip', 6800.00, 'https://images.pexels.com/photos/6256619/pexels-photo-6256619.jpeg?auto=compress&cs=tinysrgb&w=800', 'steel-tip', 20, 4.8, false),
  ('Dart Shafts Set', 'Aluminum dart shafts in multiple lengths, pack of 9', 1200.00, 'https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg?auto=compress&cs=tinysrgb&w=800', 'accessories', 40, 4.4, false),
  ('Dartboard Surround', 'Protective EVA foam dartboard surround in black', 2500.00, 'https://images.pexels.com/photos/4219654/pexels-photo-4219654.jpeg?auto=compress&cs=tinysrgb&w=800', 'accessories', 18, 4.6, false)
ON CONFLICT DO NOTHING;