import React, { createContext, useContext, useState, useEffect } from 'react'
import { CartItem, Product } from '../types'
import { supabase } from '../lib/supabase'

interface CartContextType {
  cartItems: CartItem[]
  addToCart: (product: Product, quantity?: number) => Promise<void>
  removeFromCart: (itemId: string) => Promise<void>
  updateQuantity: (itemId: string, quantity: number) => Promise<void>
  clearCart: () => Promise<void>
  cartCount: number
  cartTotal: number
  userId: string
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [userId, setUserId] = useState<string>('')

  useEffect(() => {
    let storedUserId = localStorage.getItem('dart_user_id')
    if (!storedUserId) {
      storedUserId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      localStorage.setItem('dart_user_id', storedUserId)
    }
    setUserId(storedUserId)
    loadCart(storedUserId)
  }, [])

  const loadCart = async (uid: string) => {
    const { data, error } = await supabase
      .from('cart_items')
      .select('*, product:products(*)')
      .eq('user_id', uid)

    if (!error && data) {
      setCartItems(data as CartItem[])
    }
  }

  const addToCart = async (product: Product, quantity: number = 1) => {
    const existingItem = cartItems.find(item => item.product_id === product.id)

    if (existingItem) {
      await updateQuantity(existingItem.id, existingItem.quantity + quantity)
    } else {
      const { data, error } = await supabase
        .from('cart_items')
        .insert({
          user_id: userId,
          product_id: product.id,
          quantity
        })
        .select('*, product:products(*)')
        .single()

      if (!error && data) {
        setCartItems([...cartItems, data as CartItem])
      }
    }
  }

  const removeFromCart = async (itemId: string) => {
    await supabase.from('cart_items').delete().eq('id', itemId)
    setCartItems(cartItems.filter(item => item.id !== itemId))
  }

  const updateQuantity = async (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeFromCart(itemId)
      return
    }

    const { data, error } = await supabase
      .from('cart_items')
      .update({ quantity })
      .eq('id', itemId)
      .select('*, product:products(*)')
      .single()

    if (!error && data) {
      setCartItems(cartItems.map(item => item.id === itemId ? data as CartItem : item))
    }
  }

  const clearCart = async () => {
    await supabase.from('cart_items').delete().eq('user_id', userId)
    setCartItems([])
  }

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0)
  const cartTotal = cartItems.reduce((sum, item) => {
    const price = item.product?.price || 0
    return sum + (price * item.quantity)
  }, 0)

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      cartCount,
      cartTotal,
      userId
    }}>
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return context
}
