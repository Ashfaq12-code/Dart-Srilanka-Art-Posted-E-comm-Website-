import React from 'react'
import { Link } from 'react-router-dom'
import { Product } from '../types'

interface ProductCardProps {
  product: Product
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-LK', {
      style: 'currency',
      currency: 'LKR',
      minimumFractionDigits: 0
    }).format(price)
  }

  return (
    <Link to={`/product/${product.id}`} className="glass-card-hover overflow-hidden group">
      <div className="relative overflow-hidden aspect-square">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {product.stock < 10 && (
          <div className="absolute top-3 right-3 bg-white text-black px-3 py-1 rounded-full text-xs font-bold">
            Only {product.stock} left!
          </div>
        )}
      </div>

      <div className="p-4 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400 uppercase tracking-wider">
            {product.category.replace('-', ' ')}
          </span>
          <div className="flex items-center space-x-1">
            <span className="text-yellow-400">⭐</span>
            <span className="text-sm font-medium">{product.rating}</span>
          </div>
        </div>

        <h3 className="font-bold text-lg line-clamp-2 group-hover:text-gray-300 transition-colors">
          {product.name}
        </h3>

        <p className="text-sm text-gray-400 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between pt-2">
          <span className="text-2xl font-bold">{formatPrice(product.price)}</span>
          <span className="glass-button text-sm py-2 px-4">
            View Details
          </span>
        </div>
      </div>
    </Link>
  )
}

export default ProductCard
