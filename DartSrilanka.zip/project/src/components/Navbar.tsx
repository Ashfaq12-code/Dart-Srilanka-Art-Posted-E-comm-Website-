import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import Chatbot from './Chatbot'

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const { cartCount } = useCart()

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Shop', path: '/shop' },
    { name: 'Categories', path: '/categories' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
    { name: 'Orders', path: '/orders' },
    { name: 'Admin', path: '/admin' },
    { name: 'Cart', path: '/cart', badge: cartCount }
  ]

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-2xl">
                🎯
              </div>
              <span className="text-xl font-bold text-shadow">Dart Store</span>
            </Link>

            <div className="hidden md:flex items-center space-x-6">
              {navLinks.map(link => (
                <Link
                  key={link.path}
                  to={link.path}
                  className="relative text-sm font-medium hover:text-gray-300 transition-colors"
                >
                  {link.name}
                  {link.badge ? (
                    <span className="absolute -top-2 -right-2 bg-white text-black text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                      {link.badge}
                    </span>
                  ) : null}
                </Link>
              ))}
              <button
                onClick={() => setIsChatOpen(true)}
                className="glass-button text-sm py-2"
              >
                💬 Chat
              </button>
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden glass-card p-2"
            >
              <div className="w-6 h-5 flex flex-col justify-between">
                <span className={`w-full h-0.5 bg-white transition-all ${isMenuOpen ? 'rotate-45 translate-y-2' : ''}`}></span>
                <span className={`w-full h-0.5 bg-white transition-all ${isMenuOpen ? 'opacity-0' : ''}`}></span>
                <span className={`w-full h-0.5 bg-white transition-all ${isMenuOpen ? '-rotate-45 -translate-y-2' : ''}`}></span>
              </div>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden glass-card border-t border-white/10 absolute top-16 left-0 right-0">
            <div className="px-4 py-4 space-y-3">
              {navLinks.map(link => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMenuOpen(false)}
                  className="block py-2 text-sm font-medium hover:text-gray-300 transition-colors relative"
                >
                  {link.name}
                  {link.badge ? (
                    <span className="ml-2 bg-white text-black text-xs rounded-full px-2 py-0.5 font-bold">
                      {link.badge}
                    </span>
                  ) : null}
                </Link>
              ))}
              <button
                onClick={() => {
                  setIsChatOpen(true)
                  setIsMenuOpen(false)
                }}
                className="w-full glass-button text-sm py-2 text-left"
              >
                💬 Chat
              </button>
            </div>
          </div>
        )}
      </nav>

      {isChatOpen && <Chatbot onClose={() => setIsChatOpen(false)} />}
    </>
  )
}

export default Navbar
