import React, { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Product } from '../types'
import ProductCard from './ProductCard'

interface ProductGridProps {
  featured?: boolean
  limit?: number
  showMoreButton?: boolean
}

const ProductGrid: React.FC<ProductGridProps> = ({
  featured = false,
  limit = 6,
  showMoreButton = true
}) => {
  const [products, setProducts] = useState<Product[]>([])
  const [displayCount, setDisplayCount] = useState(limit)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadProducts()
  }, [featured])

  const loadProducts = async () => {
    setLoading(true)
    let query = supabase.from('products').select('*')

    if (featured) {
      query = query.eq('is_featured', true)
    }

    const { data, error } = await query.order('created_at', { ascending: false })

    if (!error && data) {
      setProducts(data)
    }
    setLoading(false)
  }

  const displayedProducts = products.slice(0, displayCount)
  const hasMore = displayCount < products.length

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map(i => (
          <div key={i} className="glass-card h-96 animate-pulse" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayedProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {showMoreButton && hasMore && (
        <div className="flex justify-center">
          <button
            onClick={() => setDisplayCount(prev => prev + 6)}
            className="glass-button text-lg px-8 py-4"
          >
            Show More Products
          </button>
        </div>
      )}
    </div>
  )
}

export default ProductGrid
