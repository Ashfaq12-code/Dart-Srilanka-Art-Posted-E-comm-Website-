import React, { useState } from 'react'

interface ChatbotProps {
  onClose: () => void
}

interface Message {
  text: string
  isBot: boolean
}

const Chatbot: React.FC<ChatbotProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    { text: 'Hi! 👋 Welcome to Dart Store. How can I help you today?', isBot: true }
  ])
  const [input, setInput] = useState('')

  const quickReplies = [
    'Show me dart boards',
    'Delivery info',
    'Contact WhatsApp',
    'Track my order'
  ]

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage = input
    setMessages([...messages, { text: userMessage, isBot: false }])
    setInput('')

    setTimeout(() => {
      let botResponse = ''
      const lowerInput = userMessage.toLowerCase()

      if (lowerInput.includes('dart') || lowerInput.includes('board')) {
        botResponse = 'We have premium dart boards starting from Rs. 8,500! Check our Shop page to see all products. 🎯'
      } else if (lowerInput.includes('delivery') || lowerInput.includes('ship')) {
        botResponse = 'We deliver island-wide across Sri Lanka! Orders are processed within 24 hours. 🚚'
      } else if (lowerInput.includes('whatsapp') || lowerInput.includes('contact')) {
        botResponse = 'Contact us on WhatsApp: 077 620 7299. We respond quickly! 📱'
      } else if (lowerInput.includes('order') || lowerInput.includes('track')) {
        botResponse = 'You can track your orders in the Orders page. Need help? Message us on WhatsApp!'
      } else if (lowerInput.includes('price') || lowerInput.includes('cost')) {
        botResponse = 'Our dart boards range from Rs. 8,500 - Rs. 15,000. Darts start from Rs. 850. Check the Shop page! 💰'
      } else {
        botResponse = 'Thanks for your message! For quick assistance, contact us on WhatsApp: 077 620 7299 📞'
      }

      setMessages(prev => [...prev, { text: botResponse, isBot: true }])
    }, 500)
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end md:items-center justify-center p-4">
      <div className="glass-card w-full md:w-96 max-h-[600px] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-white/10">
          <h3 className="text-lg font-bold">Chat Support</h3>
          <button
            onClick={onClose}
            className="glass-card hover:bg-white/20 w-8 h-8 rounded-full flex items-center justify-center transition-all"
          >
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.isBot ? 'justify-start' : 'justify-end'}`}
            >
              <div
                className={`max-w-[80%] px-4 py-2 rounded-2xl ${
                  msg.isBot
                    ? 'glass-card'
                    : 'bg-white text-black'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-white/10 space-y-3">
          <div className="flex flex-wrap gap-2">
            {quickReplies.map((reply, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInput(reply)
                  setTimeout(() => handleSend(), 100)
                }}
                className="glass-card hover:bg-white/20 px-3 py-1 text-xs rounded-full transition-all"
              >
                {reply}
              </button>
            ))}
          </div>

          <div className="flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type your message..."
              className="glass-input flex-1 text-sm"
            />
            <button
              onClick={handleSend}
              className="glass-button px-4"
            >
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Chatbot
