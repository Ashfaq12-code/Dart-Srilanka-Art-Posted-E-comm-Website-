import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'

const HeroSection: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      title: 'Hit Your Target 🎯',
      subtitle: 'Premium Dart Boards & Accessories',
      description: '58K+ TikTok followers trust us | Island-wide delivery',
      image: 'https://images.pexels.com/photos/3178786/pexels-photo-3178786.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      cta: 'Shop Now'
    },
    {
      title: 'Professional Quality',
      subtitle: 'Tournament-Grade Equipment',
      description: 'From beginners to pros | Best prices in Sri Lanka',
      image: 'https://images.pexels.com/photos/6256619/pexels-photo-6256619.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      cta: 'View Collection'
    },
    {
      title: 'Fast Island-Wide Delivery',
      subtitle: 'Order Today, Delivered Tomorrow',
      description: 'Free shipping on orders over Rs. 10,000',
      image: 'https://images.pexels.com/photos/3621958/pexels-photo-3621958.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080',
      cta: 'Contact Us'
    }
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const goToSlide = (index: number) => {
    setCurrentSlide(index)
  }

  return (
    <div className="relative h-screen overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url(${slide.image})` }}
          >
            <div className="absolute inset-0 bg-black/60" />
          </div>

          <div className="relative h-full flex items-center justify-center text-center px-4">
            <div className="max-w-4xl">
              <h1 className="text-5xl md:text-7xl font-bold mb-4 text-shadow">
                {slide.title}
              </h1>
              <p className="text-2xl md:text-3xl mb-3 text-shadow">
                {slide.subtitle}
              </p>
              <p className="text-lg md:text-xl mb-8 text-gray-300 text-shadow">
                {slide.description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/shop" className="glass-button text-lg glow">
                  {slide.cta}
                </Link>
                <a
                  href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-button text-lg"
                >
                  💬 WhatsApp Order
                </a>
              </div>
            </div>
          </div>
        </div>
      ))}

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3 z-10">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentSlide
                ? 'bg-white w-8'
                : 'bg-white/50 hover:bg-white/75'
            }`}
          />
        ))}
      </div>
    </div>
  )
}

export default HeroSection
