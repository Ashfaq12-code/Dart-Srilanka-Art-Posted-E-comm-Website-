import React, { useState } from 'react'

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  })

  const handleWhatsAppContact = () => {
    const message = `Hi! I'm ${formData.name}\n\nEmail: ${formData.email}\n\nMessage: ${formData.message}`
    const whatsappUrl = `https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, '_blank')
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-shadow">Get In Touch</h1>
          <p className="text-xl text-gray-300">We'd love to hear from you!</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="glass-card p-8 space-y-6">
            <h2 className="text-2xl font-bold">Contact Information</h2>

            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="glass-card w-12 h-12 flex items-center justify-center text-2xl flex-shrink-0">
                  📱
                </div>
                <div>
                  <h3 className="font-bold mb-1">Phone / WhatsApp</h3>
                  <a
                    href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
                    className="text-gray-300 hover:text-white transition-colors"
                  >
                    077 620 7299
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="glass-card w-12 h-12 flex items-center justify-center text-2xl flex-shrink-0">
                  📍
                </div>
                <div>
                  <h3 className="font-bold mb-1">Location</h3>
                  <p className="text-gray-300">Sri Lanka<br />Island-wide Delivery Available</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="glass-card w-12 h-12 flex items-center justify-center text-2xl flex-shrink-0">
                  ⏰
                </div>
                <div>
                  <h3 className="font-bold mb-1">Business Hours</h3>
                  <p className="text-gray-300">Monday - Sunday<br />9:00 AM - 9:00 PM</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="glass-card w-12 h-12 flex items-center justify-center text-2xl flex-shrink-0">
                  📱
                </div>
                <div>
                  <h3 className="font-bold mb-1">TikTok</h3>
                  <p className="text-gray-300">@dartstore_lk<br />58K+ Followers</p>
                </div>
              </div>
            </div>

            <a
              href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full glass-button py-4 text-lg font-bold text-center glow"
            >
              💬 Chat on WhatsApp
            </a>
          </div>

          <div className="glass-card p-8 space-y-6">
            <h2 className="text-2xl font-bold">Send Us a Message</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Your Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your name"
                  className="glass-input"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="your@email.com"
                  className="glass-input"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="How can we help you?"
                  rows={6}
                  className="glass-input min-h-32"
                />
              </div>

              <button
                onClick={handleWhatsAppContact}
                className="w-full glass-button py-4 text-lg font-bold"
              >
                Send via WhatsApp
              </button>
            </div>
          </div>
        </div>

        <div className="glass-card p-8 text-center space-y-4">
          <h2 className="text-3xl font-bold">Frequently Asked Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
            <div className="glass-card p-4">
              <h3 className="font-bold mb-2">🚚 Do you deliver island-wide?</h3>
              <p className="text-gray-300 text-sm">Yes! We deliver to all areas across Sri Lanka.</p>
            </div>
            <div className="glass-card p-4">
              <h3 className="font-bold mb-2">💰 What payment methods do you accept?</h3>
              <p className="text-gray-300 text-sm">Bank transfer, cash on delivery, and online payments.</p>
            </div>
            <div className="glass-card p-4">
              <h3 className="font-bold mb-2">📦 How long does delivery take?</h3>
              <p className="text-gray-300 text-sm">Usually 2-5 business days depending on your location.</p>
            </div>
            <div className="glass-card p-4">
              <h3 className="font-bold mb-2">↩️ What's your return policy?</h3>
              <p className="text-gray-300 text-sm">7-day returns for defective products. Contact us for details.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Contact
