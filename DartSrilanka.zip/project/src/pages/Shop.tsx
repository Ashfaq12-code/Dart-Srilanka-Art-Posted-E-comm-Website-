import React, { useState } from 'react'
import ProductGrid from '../components/ProductGrid'

const Shop: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all')

  const categories = [
    { id: 'all', name: 'All Products', icon: '🎯' },
    { id: 'dart-boards', name: 'Dart Boards', icon: '🎲' },
    { id: 'steel-tip', name: 'Steel Tip Darts', icon: '🎪' },
    { id: 'soft-tip', name: 'Soft Tip Darts', icon: '🎨' },
    { id: 'accessories', name: 'Accessories', icon: '🛠️' }
  ]

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl md:text-5xl font-bold text-shadow">Shop All Products</h1>
          <p className="text-xl text-gray-300">Premium dart equipment for every skill level</p>
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`glass-button ${
                selectedCategory === cat.id ? 'glow bg-white/20' : ''
              }`}
            >
              <span className="mr-2">{cat.icon}</span>
              {cat.name}
            </button>
          ))}
        </div>

        <ProductGrid featured={false} limit={6} showMoreButton={true} />
      </div>
    </div>
  )
}

export default Shop
