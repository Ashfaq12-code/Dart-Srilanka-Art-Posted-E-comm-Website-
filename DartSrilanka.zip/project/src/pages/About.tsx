import React from 'react'

const About: React.FC = () => {
  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-4xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-shadow">About Dart Store</h1>
          <p className="text-xl text-gray-300">Sri Lanka's #1 Dart Equipment Supplier</p>
        </div>

        <div className="glass-card p-8 space-y-6">
          <div className="space-y-4">
            <h2 className="text-3xl font-bold">Who We Are</h2>
            <p className="text-lg text-gray-300 leading-relaxed">
              We're passionate dart enthusiasts dedicated to bringing premium dart boards and accessories to players across Sri Lanka. With over 58,000 followers on TikTok, we've built a community of dart lovers who trust us for quality products and excellent service.
            </p>
          </div>

          <div className="space-y-4">
            <h2 className="text-3xl font-bold">Why Choose Us?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="glass-card p-4">
                <h3 className="text-xl font-bold mb-2">🎯 Premium Quality</h3>
                <p className="text-gray-300">Tournament-grade equipment from trusted brands</p>
              </div>
              <div className="glass-card p-4">
                <h3 className="text-xl font-bold mb-2">🚚 Island-Wide Delivery</h3>
                <p className="text-gray-300">Fast shipping to anywhere in Sri Lanka</p>
              </div>
              <div className="glass-card p-4">
                <h3 className="text-xl font-bold mb-2">💰 Best Prices</h3>
                <p className="text-gray-300">Competitive pricing without compromising quality</p>
              </div>
              <div className="glass-card p-4">
                <h3 className="text-xl font-bold mb-2">💬 Great Support</h3>
                <p className="text-gray-300">24/7 customer service via WhatsApp</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-3xl font-bold">Our Mission</h2>
            <p className="text-lg text-gray-300 leading-relaxed">
              To make professional dart equipment accessible to everyone in Sri Lanka, from beginners taking their first throw to seasoned players competing in tournaments. We believe in quality, affordability, and exceptional customer service.
            </p>
          </div>

          <div className="glass-card p-6 text-center space-y-3">
            <div className="text-5xl">📱</div>
            <h3 className="text-2xl font-bold">Follow Us on TikTok</h3>
            <p className="text-gray-300">Join 58K+ followers for tips, tricks, and exclusive deals</p>
            <p className="text-3xl font-bold">@dartstore_lk</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About
