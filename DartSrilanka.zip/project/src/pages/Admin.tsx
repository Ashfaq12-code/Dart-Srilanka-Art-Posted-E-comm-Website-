import React, { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { Order } from '../types'

const Admin: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<string>('all')

  useEffect(() => {
    loadOrders()
  }, [])

  const loadOrders = async () => {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false })

    if (!error && data) {
      setOrders(data)
    }
    setLoading(false)
  }

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    const { error } = await supabase
      .from('orders')
      .update({ status: newStatus, updated_at: new Date().toISOString() })
      .eq('id', orderId)

    if (!error) {
      setOrders(orders.map(order =>
        order.id === orderId ? { ...order, status: newStatus as Order['status'] } : order
      ))
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-LK', {
      style: 'currency',
      currency: 'LKR',
      minimumFractionDigits: 0
    }).format(price)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const filteredOrders = filter === 'all'
    ? orders
    : orders.filter(order => order.status === filter)

  const stats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    approved: orders.filter(o => o.status === 'approved').length,
    shipped: orders.filter(o => o.status === 'shipped').length,
    delivered: orders.filter(o => o.status === 'delivered').length,
    revenue: orders.reduce((sum, o) => sum + o.total_amount, 0)
  }

  if (loading) {
    return (
      <div className="min-h-screen pt-24 pb-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="glass-card h-96 animate-pulse" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-bold text-shadow">Order Management</h1>
          <button onClick={loadOrders} className="glass-button">
            🔄 Refresh
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="glass-card p-4 text-center">
            <p className="text-3xl font-bold">{stats.total}</p>
            <p className="text-sm text-gray-400">Total Orders</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-yellow-400">{stats.pending}</p>
            <p className="text-sm text-gray-400">Pending</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-blue-400">{stats.approved}</p>
            <p className="text-sm text-gray-400">Approved</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-purple-400">{stats.shipped}</p>
            <p className="text-sm text-gray-400">Shipped</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-3xl font-bold text-green-400">{stats.delivered}</p>
            <p className="text-sm text-gray-400">Delivered</p>
          </div>
          <div className="glass-card p-4 text-center">
            <p className="text-xl font-bold">{formatPrice(stats.revenue)}</p>
            <p className="text-sm text-gray-400">Revenue</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          {['all', 'pending', 'approved', 'shipped', 'delivered', 'cancelled'].map(status => (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`glass-button ${filter === status ? 'glow bg-white/20' : ''}`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {filteredOrders.map(order => (
            <div key={order.id} className="glass-card p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-gray-400 mb-1">Order ID</p>
                  <p className="font-mono text-sm">{order.id.slice(0, 8)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Customer</p>
                  <p className="font-bold">{order.customer_name}</p>
                  <p className="text-sm text-gray-400">{order.customer_phone}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Total</p>
                  <p className="text-xl font-bold">{formatPrice(order.total_amount)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 mb-1">Date</p>
                  <p className="text-sm">{formatDate(order.created_at)}</p>
                </div>
              </div>

              <div>
                <p className="text-xs text-gray-400 mb-1">Delivery Address</p>
                <p className="text-sm">{order.customer_address}</p>
              </div>

              {order.notes && (
                <div>
                  <p className="text-xs text-gray-400 mb-1">Notes</p>
                  <p className="text-sm">{order.notes}</p>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => updateOrderStatus(order.id, 'pending')}
                  className={`glass-button text-sm ${order.status === 'pending' ? 'bg-yellow-500/20' : ''}`}
                >
                  ⏳ Pending
                </button>
                <button
                  onClick={() => updateOrderStatus(order.id, 'approved')}
                  className={`glass-button text-sm ${order.status === 'approved' ? 'bg-blue-500/20' : ''}`}
                >
                  ✅ Approve
                </button>
                <button
                  onClick={() => updateOrderStatus(order.id, 'shipped')}
                  className={`glass-button text-sm ${order.status === 'shipped' ? 'bg-purple-500/20' : ''}`}
                >
                  🚚 Ship
                </button>
                <button
                  onClick={() => updateOrderStatus(order.id, 'delivered')}
                  className={`glass-button text-sm ${order.status === 'delivered' ? 'bg-green-500/20' : ''}`}
                >
                  📦 Deliver
                </button>
                <button
                  onClick={() => updateOrderStatus(order.id, 'cancelled')}
                  className={`glass-button text-sm ${order.status === 'cancelled' ? 'bg-red-500/20' : ''}`}
                >
                  ❌ Cancel
                </button>
                <a
                  href={`https://wa.me/${order.customer_phone.replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-button text-sm ml-auto"
                >
                  💬 Contact Customer
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Admin
