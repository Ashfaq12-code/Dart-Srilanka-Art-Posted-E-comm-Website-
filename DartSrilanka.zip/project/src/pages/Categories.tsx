import React from 'react'
import { Link } from 'react-router-dom'

const Categories: React.FC = () => {
  const categories = [
    {
      id: 'dart-boards',
      name: 'Dart Boards',
      icon: '🎯',
      description: 'Professional and recreational dart boards for all skill levels',
      image: 'https://images.pexels.com/photos/3178786/pexels-photo-3178786.jpeg?auto=compress&cs=tinysrgb&w=800',
      count: '15+ Products'
    },
    {
      id: 'steel-tip',
      name: 'Steel Tip Darts',
      icon: '🎪',
      description: 'Premium steel tip darts for traditional dart boards',
      image: 'https://images.pexels.com/photos/6256619/pexels-photo-6256619.jpeg?auto=compress&cs=tinysrgb&w=800',
      count: '20+ Products'
    },
    {
      id: 'soft-tip',
      name: 'Soft Tip Darts',
      icon: '🎨',
      description: 'Soft tip darts perfect for electronic dart boards',
      image: 'https://images.pexels.com/photos/3683041/pexels-photo-3683041.jpeg?auto=compress&cs=tinysrgb&w=800',
      count: '18+ Products'
    },
    {
      id: 'accessories',
      name: 'Accessories',
      icon: '🛠️',
      description: 'Flights, shafts, cases, and all dart accessories',
      image: 'https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg?auto=compress&cs=tinysrgb&w=800',
      count: '30+ Products'
    }
  ]

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-shadow">Shop by Category</h1>
          <p className="text-xl text-gray-300">Find exactly what you're looking for</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categories.map(category => (
            <Link
              key={category.id}
              to="/shop"
              className="glass-card-hover overflow-hidden group"
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 space-y-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-4xl">{category.icon}</span>
                    <h2 className="text-3xl font-bold">{category.name}</h2>
                  </div>
                  <p className="text-gray-300">{category.description}</p>
                  <p className="text-sm text-gray-400">{category.count}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="glass-card p-8 text-center space-y-4">
          <h2 className="text-3xl font-bold">Can't Find What You're Looking For?</h2>
          <p className="text-xl text-gray-300">Contact us and we'll help you find the perfect dart equipment</p>
          <a
            href={`https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block glass-button text-lg px-8 py-4 glow"
          >
            💬 Contact Us on WhatsApp
          </a>
        </div>
      </div>
    </div>
  )
}

export default Categories
