import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { supabase } from '../lib/supabase'

const Cart: React.FC = () => {
  const navigate = useNavigate()
  const { cartItems, removeFromCart, updateQuantity, clearCart, cartTotal } = useCart()
  const [orderForm, setOrderForm] = useState({
    name: '',
    phone: '',
    address: '',
    notes: ''
  })
  const [ordering, setOrdering] = useState(false)
  const [showCheckout, setShowCheckout] = useState(false)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-LK', {
      style: 'currency',
      currency: 'LKR',
      minimumFractionDigits: 0
    }).format(price)
  }

  const handleWhatsAppOrder = () => {
    const items = cartItems.map(item =>
      `${item.product?.name} x${item.quantity} - ${formatPrice((item.product?.price || 0) * item.quantity)}`
    ).join('\n')

    const message = `🎯 New Order Request\n\nCustomer: ${orderForm.name}\nPhone: ${orderForm.phone}\nAddress: ${orderForm.address}\n\nItems:\n${items}\n\nTotal: ${formatPrice(cartTotal)}\n\nNotes: ${orderForm.notes || 'None'}`

    const whatsappUrl = `https://wa.me/${import.meta.env.VITE_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, '_blank')
  }

  const handlePlaceOrder = async () => {
    if (!orderForm.name || !orderForm.phone || !orderForm.address) {
      alert('Please fill in all required fields')
      return
    }

    setOrdering(true)

    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        customer_name: orderForm.name,
        customer_phone: orderForm.phone,
        customer_address: orderForm.address,
        total_amount: cartTotal,
        notes: orderForm.notes,
        status: 'pending'
      })
      .select()
      .single()

    if (!orderError && order) {
      const orderItems = cartItems.map(item => ({
        order_id: order.id,
        product_id: item.product_id,
        product_name: item.product?.name || '',
        quantity: item.quantity,
        price: item.product?.price || 0
      }))

      await supabase.from('order_items').insert(orderItems)

      handleWhatsAppOrder()
      await clearCart()

      alert('Order placed successfully! Please complete payment via WhatsApp.')
      navigate('/orders')
    } else {
      alert('Failed to place order. Please try again.')
    }

    setOrdering(false)
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-16 px-4 flex items-center justify-center">
        <div className="text-center space-y-6">
          <div className="text-6xl">🛒</div>
          <h2 className="text-3xl font-bold">Your cart is empty</h2>
          <p className="text-gray-400">Add some awesome dart products!</p>
          <button onClick={() => navigate('/shop')} className="glass-button text-lg">
            Start Shopping
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-6xl mx-auto space-y-8">
        <h1 className="text-4xl font-bold text-shadow">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map(item => (
              <div key={item.id} className="glass-card p-4 flex gap-4">
                <img
                  src={item.product?.image_url}
                  alt={item.product?.name}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div className="flex-1 space-y-2">
                  <h3 className="font-bold text-lg">{item.product?.name}</h3>
                  <p className="text-gray-400">{formatPrice(item.product?.price || 0)}</p>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="glass-button w-8 h-8 text-sm"
                    >
                      -
                    </button>
                    <span className="font-bold">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="glass-button w-8 h-8 text-sm"
                    >
                      +
                    </button>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="glass-button text-sm ml-auto"
                    >
                      Remove
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-bold">
                    {formatPrice((item.product?.price || 0) * item.quantity)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="glass-card p-6 h-fit space-y-6">
            <h3 className="text-2xl font-bold">Order Summary</h3>

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Subtotal</span>
                <span className="font-bold">{formatPrice(cartTotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Delivery</span>
                <span className="font-bold">Calculated at checkout</span>
              </div>
              <div className="border-t border-white/10 pt-2 flex justify-between text-xl">
                <span className="font-bold">Total</span>
                <span className="font-bold">{formatPrice(cartTotal)}</span>
              </div>
            </div>

            {!showCheckout ? (
              <button
                onClick={() => setShowCheckout(true)}
                className="w-full glass-button py-4 text-lg font-bold glow"
              >
                Proceed to Checkout
              </button>
            ) : (
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Full Name *"
                  value={orderForm.name}
                  onChange={(e) => setOrderForm({ ...orderForm, name: e.target.value })}
                  className="glass-input"
                />
                <input
                  type="tel"
                  placeholder="Phone Number *"
                  value={orderForm.phone}
                  onChange={(e) => setOrderForm({ ...orderForm, phone: e.target.value })}
                  className="glass-input"
                />
                <textarea
                  placeholder="Delivery Address *"
                  value={orderForm.address}
                  onChange={(e) => setOrderForm({ ...orderForm, address: e.target.value })}
                  className="glass-input min-h-24"
                />
                <textarea
                  placeholder="Additional Notes (Optional)"
                  value={orderForm.notes}
                  onChange={(e) => setOrderForm({ ...orderForm, notes: e.target.value })}
                  className="glass-input"
                />
                <button
                  onClick={handlePlaceOrder}
                  disabled={ordering}
                  className="w-full glass-button py-4 text-lg font-bold glow disabled:opacity-50"
                >
                  {ordering ? 'Placing Order...' : '💬 Order via WhatsApp'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Cart
