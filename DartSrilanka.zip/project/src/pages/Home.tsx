import React from 'react'
import { Link } from 'react-router-dom'
import HeroSection from '../components/HeroSection'
import ProductGrid from '../components/ProductGrid'

const Home: React.FC = () => {
  return (
    <div>
      <HeroSection />

      <div className="max-w-7xl mx-auto px-4 py-16 space-y-16">
        <section className="text-center space-y-4">
          <div className="glass-card inline-block px-6 py-2 rounded-full">
            <span className="text-sm font-medium">🔥 58,000+ TikTok Followers Trust Us</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-shadow">
            Premium Dart Boards & Accessories
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Island-wide delivery across Sri Lanka. Professional quality at the best prices.
          </p>
        </section>

        <section className="space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-3xl font-bold">Featured Products</h3>
            <Link to="/shop" className="glass-button">
              View All
            </Link>
          </div>
          <ProductGrid featured={true} limit={6} showMoreButton={true} />
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-card p-6 text-center space-y-3">
            <div className="text-5xl">🚚</div>
            <h4 className="text-xl font-bold">Island-Wide Delivery</h4>
            <p className="text-gray-400">Fast shipping across Sri Lanka</p>
          </div>
          <div className="glass-card p-6 text-center space-y-3">
            <div className="text-5xl">⭐</div>
            <h4 className="text-xl font-bold">Premium Quality</h4>
            <p className="text-gray-400">Tournament-grade equipment</p>
          </div>
          <div className="glass-card p-6 text-center space-y-3">
            <div className="text-5xl">💬</div>
            <h4 className="text-xl font-bold">24/7 Support</h4>
            <p className="text-gray-400">WhatsApp us anytime</p>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Home
